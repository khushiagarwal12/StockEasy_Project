<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT US</h2>
				<style>
  .grey-text {
    font-size: 35px; /* Adjust the value to your desired font size */
  }
  .grey-text b {
    text-decoration: underline;
  }
</style>	
</style>
		        <p class="grey-text text-darken-3 lighten-3"> <b>OUR MISSION</b> <br>At StockEasy, our mission is to empower businesses by revolutionizing the way they manage their inventory. We understand the challenges faced by Mini Marts and Arcades in keeping track of a diverse range of products. Our goal is to provide a user-friendly platform that not only meets these challenges head-on but also transforms them into opportunities for growth.<br><b>OUR TEAM</b> <br>Behind StockEasy is a dedicated team of professionals with expertise in software development and a deep understanding of the challenges faced by businesses in the retail and entertainment sectors. We are committed to providing top-notch support and continuously improving our platform to meet the evolving needs of our users.<br><b>JOIN US ON THE JOURNEY</b> <br>Whether you're a Mini Mart owner looking for a reliable inventory solution or an Arcade manager seeking streamlined stock control, StockEasy invites you to join us on this journey. Experience the difference of a platform designed with you in mind – where efficiency meets innovation.</P>
		      </div>
	</section>