<section class="freviews">

		<div class="section white center">
			<h3 class="header">What Our Customers Say</h3>
			<div class="carousel myreviews" style="margin-bottom: 35px;">
			    <a class="carousel-item" href="#one!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Simple and awesome! StockEasy is so user-friendly. It's like they knew we hate complicated stuff. High-fives for hassle-free stock vibes!"<br>-<br> <strong>Ramkesh Singh</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#two!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Easy peasy stock squeezy! Your service is the bomb. No more inventory nightmares, just a smooth ride. Couldn't be happier!	"<br>-<br> <strong>Rohan Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#three!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Rocking our stock! Your service is like the superhero of inventory. Quick, slick, and makes our life way cooler. Loving it!"<br>-<br> <strong>Atul Chand</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#four!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Total game-changer alert! Your stock service is like our inventory wingman. Easy, accurate, and makes us look good. What's not to love?"<br>-<br> <strong>Farhan Ahmed</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#five!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Loving the efficiency boost! Your website StockEasy made our life easier. Quick peeks, no mess-ups – it's like inventory magic. Cheers!"<br>-<br> <strong>Riya Dutta</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#six!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">Total game-changer alert! StockEasy service is like our inventory wingman. Easy, accurate, and makes us look good. What's not to love?"<br>-<br> <strong>Jasmine Sinha</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#seven!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"StockEasy in action! Your tool is a lifesaver. It's like having an inventory fairy – sprinkle, sprinkle, and everything's sorted. Kudos!"<br>-<br> <strong>Sangjukta Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			  </div>
		</div>
	</section>