<section class="fservices">
		<div class="row" style="padding-left: 50px; padding-right: 50px;">
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >local_dining</i>
				<h5 class="header" ><b>Intuitive Product Adding</b></h5>
			</div>
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >local_shipping</i>
				<h5 class="header" ><b>Customizable Categories</b></h5>
			</div>
			<div class="col s12 l4 center" style="padding: 50px 50px;">
				<i class="large material-icons" >mood</i>
				<h5 class="header" ><b>Excellent Vendor Management</b></h5>
			</div>
		</div>
	</section>