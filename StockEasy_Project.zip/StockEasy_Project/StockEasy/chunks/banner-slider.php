<section class="fslider">
		<div class="slider">
			<ul class="slides">
		    <li>
		    	<img src="images/banner3.jpg">
		    	<div class="caption center-align black-text">  
		        <h3 style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">StockEasy: Effortless Inventory, Infinite Possibilities!</h3>  
		        <h5 class="light black-text text-lighten-3"><strong>Mini Mart and Arcade  – sorted, stocked, and stress-free!</strong></h5>  
		      </div>  
		    </li>

		    <li>
		    	<img src="images/banner4.jpg">
		    	<div class="caption center-align black-text">  
		        <h3 style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">Quality Food at Your Door!</h3>  
		        <h5 class="light black-text text-lighten-3"><strong> Mini Mart and Arcade stock made simple and snappy!</strong></h5>  
		      </div>  
		    </li>
		    </ul>
		   
	  </div>
	</section>