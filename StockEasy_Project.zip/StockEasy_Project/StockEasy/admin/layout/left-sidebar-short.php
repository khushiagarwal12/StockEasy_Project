<ul class="sidenav" id="mobile-demo">
				    <li><a href="food-list.php">Foods</a></li>
			        <li><a href="category-list.php">Category</a></li>
			        <li><a href="order-list.php">Orders</a></li>
			        <li data-target="modal1" class="modal-trigger"><a href="#">About</a></li>
			        <li><a href="logout.php">Logout!</a></li>
				  </ul>


		<div class="container">
				<div class="row maincontent">
					<div class="col s12 center">